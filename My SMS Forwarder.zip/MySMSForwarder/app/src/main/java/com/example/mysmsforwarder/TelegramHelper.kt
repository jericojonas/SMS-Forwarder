package com.example.mysmsforwarder

import android.content.Context
import android.net.Uri
import android.widget.Toast
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.net.HttpURLConnection
import java.net.URL

object TelegramHelper {

    fun sendMessage(context: Context, token: String, chatId: String, message: String, sender: String = "") {
        CoroutineScope(Dispatchers.IO).launch {
            val timestamp = System.currentTimeMillis()
            try {
                val encodedMessage = Uri.encode(message)
                val urlString = "https://api.telegram.org/bot$token/sendMessage?chat_id=$chatId&text=$encodedMessage"
                val url = URL(urlString)
                val conn = url.openConnection() as HttpURLConnection
                conn.requestMethod = "GET"
                val responseCode = conn.responseCode
                conn.disconnect()

                val status = if (responseCode == 200) "Terkirim" else "Gagal"
                HistoryHelper.saveHistory(context, SmsHistory(sender, message, timestamp, status))

                withContext(Dispatchers.Main) {
                    Toast.makeText(context, "Pesan $status!", Toast.LENGTH_SHORT).show()
                }

            } catch (e: Exception) {
                HistoryHelper.saveHistory(context, SmsHistory(sender, message, timestamp, "Gagal"))
                withContext(Dispatchers.Main) {
                    Toast.makeText(context, "Error: ${e.message}", Toast.LENGTH_SHORT).show()
                }
            }
        }
    }
}
