package com.example.mysmsforwarder

import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.activity.ComponentActivity

class TestActivity : ComponentActivity() {

    private var telegramToken: String? = null
    private var telegramChatId: String? = null
    private var smsSender: String? = null
    private var smsContains: String? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_test)

        // ambil setting tersimpan
        val saved = PrefsHelper.loadSettings(this)
        telegramToken = saved["telegram_token"]
        telegramChatId = saved["telegram_chat_id"]
        smsSender = saved["sms_sender"]
        smsContains = saved["sms_contains"]

        val etSender: EditText = findViewById(R.id.etSender)
        val etMessage: EditText = findViewById(R.id.etMessage)
        val btnSend: Button = findViewById(R.id.btnSend)

        btnSend.setOnClickListener {
            val inputSender = etSender.text.toString()
            val inputMessage = etMessage.text.toString()

            if (telegramToken.isNullOrEmpty() || telegramChatId.isNullOrEmpty()) {
                Toast.makeText(this, "Silakan isi Setting dulu!", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            val senderOk = smsSender.isNullOrEmpty() || inputSender.contains(smsSender!!, ignoreCase = true)
            val containsOk = smsContains.isNullOrEmpty() || inputMessage.contains(smsContains!!, ignoreCase = true)

            if (senderOk && containsOk) {
                val msg = "From: $inputSender\n $inputMessage"
                TelegramHelper.sendMessage(this, telegramToken!!, telegramChatId!!, msg)
                Toast.makeText(this, "Pesan dikirim ke Telegram", Toast.LENGTH_SHORT).show()
            } else {
                val notOk = mutableListOf<String>()
                if (!senderOk) notOk.add("Sender tidak sesuai rule ($smsSender)")
                if (!containsOk) notOk.add("Isi pesan tidak mengandung \"$smsContains\"")
                Toast.makeText(this, "Gagal: ${notOk.joinToString(", ")}", Toast.LENGTH_LONG).show()
            }
        }
    }
}
