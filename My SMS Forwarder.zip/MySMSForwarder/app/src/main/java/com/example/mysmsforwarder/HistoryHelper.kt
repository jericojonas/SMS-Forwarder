package com.example.mysmsforwarder

import android.annotation.SuppressLint
import android.content.Context
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken


object HistoryHelper {

    private const val PREFS_NAME = "sms_history"
    private const val KEY_HISTORY = "history_list"

    @SuppressLint("UseKtx")
    fun saveHistory(context: Context, history: SmsHistory) {
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        val gson = Gson()
        val json = prefs.getString(KEY_HISTORY, null)
        val type = object : TypeToken<MutableList<SmsHistory>>() {}.type
        val list: MutableList<SmsHistory> = if (json != null) gson.fromJson(json, type) else mutableListOf()
        list.add(history)
        prefs.edit().putString(KEY_HISTORY, gson.toJson(list)).apply()
    }

    fun loadHistory(context: Context): List<SmsHistory> {
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        val gson = Gson()
        val json = prefs.getString(KEY_HISTORY, null)
        val type = object : TypeToken<List<SmsHistory>>() {}.type
        return if (json != null) gson.fromJson(json, type) else emptyList()
    }

}
