package com.example.mysmsforwarder

import android.annotation.SuppressLint
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.telephony.SmsMessage
import android.util.Log

class SmsReceiver : BroadcastReceiver() {

    @SuppressLint("UnsafeProtectedBroadcastReceiver")
    override fun onReceive(context: Context, intent: Intent) {
        val bundle = intent.extras
        @Suppress("DEPRECATION") val pdus = bundle?.get("pdus") as? Array<*> ?: return

        val saved = PrefsHelper.loadSettings(context)
        val telegramToken = saved["telegram_token"]
        val telegramChatId = saved["telegram_chat_id"]
        val smsSenderRule = saved["sms_sender"]
        val smsContainsRule = saved["sms_contains"]

        for (pdu in pdus) {
            @Suppress("DEPRECATION") val sms = SmsMessage.createFromPdu(pdu as ByteArray)
            val sender = sms.displayOriginatingAddress ?: ""
            val message = sms.displayMessageBody ?: ""

            val senderOk = smsSenderRule.isNullOrEmpty() || sender.contains(smsSenderRule, ignoreCase = true)
            val containsOk = smsContainsRule.isNullOrEmpty() || message.contains(smsContainsRule, ignoreCase = true)

            if (senderOk && containsOk) {
                val fullMsg = "Pesan dari: $sender\n$message"
                if (!telegramToken.isNullOrEmpty() && !telegramChatId.isNullOrEmpty()) {
                    TelegramHelper.sendMessage(context, telegramToken, telegramChatId, fullMsg)
                }
            } else {
                Log.d("SmsReceiver", "SMS tidak memenuhi rule: $sender | $message")
            }
        }
    }
}
