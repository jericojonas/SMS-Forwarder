package com.example.mysmsforwarder

import android.os.Bundle
import android.widget.Button
import android.widget.Toast
import androidx.activity.ComponentActivity
import android.content.Intent
import android.Manifest
import android.content.pm.PackageManager
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat


data class SmsHistory(
    val sender: String,
    val message: String,
    val timestamp: Long,
    val status: String // "Terkirim", "Pending", "Gagal"
)

class MainActivity : ComponentActivity() {

    private var telegramToken: String? = null
    private var telegramChatId: String? = null
    private var smsSender: String? = null
    private var smsContains: String? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // --- cek permission RECEIVE_SMS ---
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECEIVE_SMS)
            != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this,
                arrayOf(Manifest.permission.RECEIVE_SMS), 100)
        }

        // Load setting yang tersimpan
        val saved = PrefsHelper.loadSettings(this)
        telegramToken = saved["telegram_token"]
        telegramChatId = saved["telegram_chat_id"]
        smsSender = saved["sms_sender"]
        smsContains = saved["sms_contains"]

        val btnSetting: Button = findViewById(R.id.btnSetting)
        val btnTest: Button = findViewById(R.id.btnTest)
        val btnHistory: Button = findViewById(R.id.btnHistory)

        btnSetting.setOnClickListener {
            TelegramSettingDialog(
                this,
                telegramToken,
                telegramChatId,
                smsSender,
                smsContains
            ) { token, chatId, sender, contains ->
                telegramToken = token
                telegramChatId = chatId
                smsSender = sender
                smsContains = contains

                // Simpan permanen ke SharedPreferences
                PrefsHelper.saveSettings(this, token, chatId, sender, contains)
            }.show()
        }

        btnTest.setOnClickListener {
            if (telegramToken.isNullOrEmpty() || telegramChatId.isNullOrEmpty()) {
                Toast.makeText(this, "Silakan isi Setting dulu!", Toast.LENGTH_SHORT).show()
            } else {
                startActivity(Intent(this, TestActivity::class.java))
            }
        }

        btnHistory.setOnClickListener {
            startActivity(Intent(this, HistoryActivity::class.java))
        }
    }
}
