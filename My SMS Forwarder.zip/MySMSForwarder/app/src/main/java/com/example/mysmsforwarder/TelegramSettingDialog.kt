package com.example.mysmsforwarder

import android.content.Context
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.Toast
import androidx.appcompat.app.AlertDialog

class TelegramSettingDialog(
    private val context: Context,
    private var token: String?,
    private var chatId: String?,
    private var smsSender: String?,       // nomor pengirim filter
    private var smsContains: String?,     // kata kunci filter
    private val onSave: (String, String, String, String) -> Unit
) {

    fun show() {
        // LinearLayout untuk menampung EditText
        val layout = LinearLayout(context)
        layout.orientation = LinearLayout.VERTICAL
        layout.setPadding(50, 40, 50, 10)

        // EditText Token
        val tokenInput = EditText(context)
        tokenInput.hint = "Telegram Bot Token"
        if (token != null) tokenInput.setText(token)

        // EditText Chat ID
        val chatIdInput = EditText(context)
        chatIdInput.hint = "Telegram Chat ID"
        if (chatId != null) chatIdInput.setText(chatId)

        // SMS Sender
        val senderInput = EditText(context)
        senderInput.hint = "Sender (nomor)"
        if (smsSender != null) senderInput.setText(smsSender)

        // SMS Contains
        val containsInput = EditText(context)
        containsInput.hint = "SMS contains (kata kunci)"
        if (smsContains != null) containsInput.setText(smsContains)

        layout.addView(tokenInput)
        layout.addView(chatIdInput)
        layout.addView(senderInput)
        layout.addView(containsInput)

        // Tampilkan dialog
        AlertDialog.Builder(context, androidx.appcompat.R.style.Theme_AppCompat_Light_Dialog)
            .setTitle("Telegram Setting")
            .setView(layout)
            .setPositiveButton("Simpan") { _, _ ->
                val t = tokenInput.text.toString()
                val c = chatIdInput.text.toString()
                val s = senderInput.text.toString()
                val k = containsInput.text.toString()
                onSave(t, c, s, k) // aman, tidak pakai !!
                Toast.makeText(context, "Setting tersimpan!", Toast.LENGTH_SHORT).show()
            }
            .setNegativeButton("Batal", null)
            .show()
    }
}
