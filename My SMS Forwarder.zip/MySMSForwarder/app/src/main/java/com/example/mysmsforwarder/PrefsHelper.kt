package com.example.mysmsforwarder

import android.content.Context

object PrefsHelper {
    private const val PREFS_NAME = "MySmsForwarderPrefs"
    private const val KEY_TOKEN = "telegram_token"
    private const val KEY_CHAT_ID = "telegram_chat_id"
    private const val KEY_SENDER = "sms_sender"
    private const val KEY_CONTAINS = "sms_contains"

    fun saveSettings(context: Context, token: String, chatId: String, sender: String, contains: String) {
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        prefs.edit().apply {
            putString(KEY_TOKEN, token)
            putString(KEY_CHAT_ID, chatId)
            putString(KEY_SENDER, sender)
            putString(KEY_CONTAINS, contains)
            apply()
        }
    }

    fun loadSettings(context: Context): Map<String, String?> {
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        return mapOf(
            KEY_TOKEN to prefs.getString(KEY_TOKEN, null),
            KEY_CHAT_ID to prefs.getString(KEY_CHAT_ID, null),
            KEY_SENDER to prefs.getString(KEY_SENDER, null),
            KEY_CONTAINS to prefs.getString(KEY_CONTAINS, null)
        )
    }
}
